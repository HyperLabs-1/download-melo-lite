# Deploying Melo Lite — free, no backend server needed

You have two things to host: the **website** (static files) and the **APK**
(a 53.5MB binary). Keep them on two different free services — this is the
standard, cheapest, fastest approach and avoids file-size limits on most
static hosts.

## 1. Host the APK on GitHub Releases (free, up to 2GB per file)

1. Create a free GitHub account if you don't have one: https://github.com/signup
2. Create a new repository (public or private — public is simpler and free either way for this).
3. Open the repo → **Releases** (right sidebar) → **Create a new release**.
4. Set a tag, e.g. `v1.0.0`.
5. Drag `androidapp-universal-release.apk` into the "Attach binaries" box.
6. Click **Publish release**.
7. Click the APK file name in the published release to copy its direct link.
   It will look like:
   `https://github.com/YOUR_USERNAME/YOUR_REPO/releases/download/v1.0.0/androidapp-universal-release.apk`

That link downloads the file directly when clicked — no server code required.

## 2. Host the website

Pick any of these (all free for a static site this size):

- **Netlify** — https://app.netlify.com/drop — drag the `melo-lite-site` folder
  straight into the browser, done in ~30 seconds. Gives you a
  `yourname.netlify.app` URL immediately, custom domain optional.
- **Cloudflare Pages** — https://pages.cloudflare.com — same drag-and-drop
  flow, or connect a GitHub repo for auto-deploy on every push.
- **GitHub Pages** — if your site lives in the same repo as step 1:
  Settings → Pages → deploy from the `main` branch. URL will be
  `yourusername.github.io/your-repo`.
- **Vercel** — https://vercel.com/new — similar to Netlify, great if you
  might add more pages later.

If you use the multi-file version (`index.html` + `images/` folder), upload
both together, keeping the folder structure intact. If you use the
single-file version (`melo-lite-landing.html`, images already embedded),
just upload that one file and rename it to `index.html` on your host.

## 3. Connect the download button

Open `index.html`, find this near the top of the `<script>` tag:

```js
const APK_DOWNLOAD_URL = "REPLACE_WITH_YOUR_APK_RELEASE_URL";
```

Replace the placeholder with your GitHub Releases link from step 1, save,
and redeploy (or just re-drag the folder into Netlify/Cloudflare — takes
seconds).

## Notes

- GitHub Releases has no practical bandwidth limit for a project this size —
  fine for free, public distribution.
- If Melo Lite ever needs analytics on downloads, update counts, or crash
  reporting, that's when an actual backend (or a service like Firebase)
  becomes useful — not needed just to serve the file.
- Total cost for all of the above: $0. A custom domain (optional) is the
  only thing that costs money, roughly $10–15/year from any registrar.
